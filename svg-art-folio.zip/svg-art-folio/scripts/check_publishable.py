"""Check a repository staging directory for publishable hygiene."""
from pathlib import Path
import hashlib, json, re, sys, zipfile
root=Path(sys.argv[1] if len(sys.argv)>1 else ".")
assert not any(p.name in {".env", ".DS_Store"} or p.suffix==".log" for p in root.rglob("*")), "temporary file found"
files=[p for p in root.rglob("*") if p.is_file()]
text="\n".join(re.sub(r"<script\b.*?</script>", "", p.read_text(encoding="utf-8",errors="ignore"), flags=re.S|re.I) for p in files if p.suffix.lower() not in {".zip",".png",".jpg",".webp"} and "scripts" not in p.parts)
assert not re.search(r"eo_token|eo_time|BEGIN (?:RSA|OPENSSH) PRIVATE KEY|github_pat_[A-Za-z0-9_]+",text,re.I), "credential-like text found"
for name in ("Shu.zip","svg-art-folio.zip"):
 with zipfile.ZipFile(root/name) as z: assert z.testzip() is None
print(json.dumps({"files":len(files),"credential_scan":True,"archives_valid":True},ensure_ascii=False))
